var prefix = window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );
var config = {
        host: window.location.hostname,
        prefix: prefix,
        isSecure: true,
        app: "Deloitte Mashup Workshop.qvf"
      };
      senseSearch.connect(config, function(){
        var resultOptions = {
           "fields":[
              {
                "dimension": "Country",
                "suppressNull": true
              },
              {
                "dimension": "Product",
                "suppressNull": false
              },
              {
                "measure": "sum(SalesAmount)",
                "label": "SalesAmount",
                "sortType" : "qSortByNumeric",
                "order" : -1
              }
           ],
           "sortOptions": {
             "Country": {
                "name": "A-Z",
                "order": 1,
                "field": "Country",
                "sortType": "qSortByAscii"
              }
           },
           "defaultSort": "Country"
        }
        var inputOptions = {
          "searchFields": ["SearchField"],
          "suggestFields": ["Country","Product"]
        }
        senseSearch.inputs["myInput"].attach(inputOptions);
        senseSearch.results["myResults"].attach(resultOptions);
      });
